package Model;

import java.time.LocalDate;
import java.util.ArrayList;


public class InvoiceLine {
    
     private String invoiceNumber;

    private String Name;
 
    private int price;
    private int count;


    public InvoiceLine( String invoiceNumber,String Name,int price,int count) {
        this.invoiceNumber=invoiceNumber;
        this.Name = Name;
        this.count = count;
        this.price = price;


    }

    public InvoiceLine() {
            }

    /**
     * @return the invoiceNumber
     */
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    /**
     * @param invoiceNumber the invoiceNumber to set
     */
    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    /**
     * @return the Name
     */
    public String getName() {
        return Name;
    }

    /**
     * @param Name the Name to set
     */
    public void setName(String Name) {
        this.Name = Name;
    }

    /**
     * @return the price
     */
    public int getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(int price) {
        this.price = price;
    }

    /**
     * @return the count
     */
    public int getCount() {
        return count;
    }

    /**
     * @param count the count to set
     */
    public void setCount(int count) {
        this.count = count;
    }

     @Override
    public String  toString(){
        return this.Name+", "+this.price+", "+this.count;
                
    }




}
