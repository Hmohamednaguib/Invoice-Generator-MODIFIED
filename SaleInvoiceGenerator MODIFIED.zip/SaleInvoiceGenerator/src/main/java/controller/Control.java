package controller;


import Database.FileOperations;
import Database.FileOperations1;
import Model.InvoiceHeader;
import Model.InvoiceLine;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Control {
    
  public static ArrayList<InvoiceHeader>  list=new ArrayList();

   public static void removeInvoice(String number) {
         
			for (int i = 0; i < list.size(); i++) {
				InvoiceHeader member = (InvoiceHeader) list.get(i);
				if (member.getInvoiceNumber().equalsIgnoreCase(number))
					list.remove(i);
			}
			
    
    }
    public static int getPrice(String name) {
         
			for (int i = 0; i < list.size(); i++) {
				for (int j = 0; j < list.get(i).getItems().size(); j++) {
				if (list.get(i).getItems().get(j).getName().equalsIgnoreCase(name))
					return list.get(i).getItems().get(j).getPrice();
			}
                        }
                        return 0;
			
    
    }
   
   public static ArrayList<InvoiceHeader> load( String name){
        if(list.size()==0 || !name.isBlank() ){
            list = FileOperations.readFile( name);
        }
      
      return list;
    }
    public static void save( String name){
      FileOperations.saveFile(name,list);
       
       ArrayList<InvoiceLine> inv=new  ArrayList();
        for(int i=0;i<list.size();i++){
            inv.addAll(list.get(i).getItems());
        }
       FileOperations1.saveFile(inv);
      
    }
    public  static ArrayList<InvoiceLine> getInvoiceLine(String number){
     for (int i = 0; i < list.size(); i++) {
				InvoiceHeader member = (InvoiceHeader) list.get(i);
				if (member.getInvoiceNumber().equalsIgnoreCase(number))
					return member.getItems();
			}
     return null;
    }
      public    static InvoiceHeader getInvoiceHeader(String number){
     for (int i = 0; i < list.size(); i++) {
				InvoiceHeader member = (InvoiceHeader) list.get(i);
				if (member.getInvoiceNumber().equalsIgnoreCase(number))
					return member;
			}
     return null;
    }
     public static void updateInvoiceHeader(InvoiceHeader ms){
       
       
		for (int i = 0; i < list.size(); i++) {
			
			if (list.get(i).getInvoiceNumber().equals(ms.getInvoiceNumber())) {
				list.set(i, ms);
                                System.out.println(ms.getCustomer());
		}
		}
		
   }
       public static void addInvoice(InvoiceHeader ms){
       
       
		list.add(ms);
		
   }
       
  
}
