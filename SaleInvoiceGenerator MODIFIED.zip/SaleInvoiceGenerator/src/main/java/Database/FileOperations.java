package Database;

import Model.InvoiceHeader;
import Model.InvoiceLine;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

public class FileOperations {

  //  public static final String DB_FILENAME = "InvoiceHeader.csv";
    public static final String SEPARATOR = ",";

    /**
     * Database Function *
     */
    /**
     * Read and Write from database
     *
     * @return e*
     */
    public static ArrayList<InvoiceHeader> readFile( String name) {
        ArrayList<String> stringArray;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        ArrayList<InvoiceHeader> alr = new ArrayList<>();
        try {
            stringArray = DatabaseIO.read(name);

            for (int i = 0; i < stringArray.size(); i++) {
                String st = (String) stringArray.get(i);
                StringTokenizer star = new StringTokenizer(st, SEPARATOR);

                String no = star.nextToken().trim();
                String date = star.nextToken().trim();

                String customer = star.nextToken().trim();
                

                InvoiceHeader stud = new InvoiceHeader(no, LocalDate.parse(date,formatter), customer);
                ArrayList<InvoiceLine> inv = FileOperations1.readFile();
                for (int j = 0; j< inv.size(); j++) {
				
				if (inv.get(j).getInvoiceNumber().equalsIgnoreCase(no)){
                                    stud.getItems().add(inv.get(j));
                                }
					
			}
                alr.add(stud);
            }
        } catch (IOException ex) {
             JOptionPane.showMessageDialog(null, "File not Found ");
        }

        return alr;
    }

    /**
     * Save the list in database
     *
     * @param name
     * @param al
     */
    public static void saveFile( String name,List<InvoiceHeader> al) {

        List<String> alw = new ArrayList<>();

        for (int i = 0; i < al.size(); i++) {
            InvoiceHeader stud = (InvoiceHeader) al.get(i);
            StringBuilder st = new StringBuilder();
            st.append(stud.getInvoiceNumber().trim());
            st.append(SEPARATOR);
            st.append(stud.getDate());
            st.append(SEPARATOR);
            st.append(stud.getCustomer());
            
            alw.add(st.toString());
        }

        try {
            DatabaseIO.write(name, alw);
        } catch (IOException ex) {
             JOptionPane.showMessageDialog(null, "File not Found ");
        }
    }

}
